--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.5 (Debian 15.5-0+deb12u1)
-- Dumped by pg_dump version 15.5 (Debian 15.5-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE real_estate;
--
-- Name: real_estate; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE real_estate WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE real_estate OWNER TO postgres;

\connect real_estate

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: inspection_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_results (
    id bigint NOT NULL,
    inspection_result_id text,
    property_id text,
    inspection_date timestamp with time zone,
    satisfactory boolean,
    comment text,
    landlord_view boolean,
    tenant_view boolean,
    image_1 text,
    image_1_comment text,
    image_2 text,
    image_2_comment text,
    image_3 text,
    image_3_comment text,
    image_4 text,
    image_4_comment text,
    image_5 text,
    image_5_comment text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.inspection_results OWNER TO postgres;

--
-- Name: inspection_results_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inspection_results_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inspection_results_id_seq OWNER TO postgres;

--
-- Name: inspection_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inspection_results_id_seq OWNED BY public.inspection_results.id;


--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    id bigint NOT NULL,
    property_id text,
    status text,
    user_id text,
    amount numeric,
    address text,
    coordinate text,
    location text,
    postal_code text,
    street_address text,
    property_type text,
    images character varying(500),
    reception_number bigint,
    bed_number bigint,
    bath_number bigint,
    property_details text,
    epc text,
    is_student_property boolean,
    features character varying(500),
    furnished text,
    next_inspection_date timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    latitude numeric,
    longitude numeric,
    landlord_id text,
    tenant_id text,
    inspected boolean
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.properties_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.properties_id_seq OWNER TO postgres;

--
-- Name: properties_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.properties_id_seq OWNED BY public.properties.id;


--
-- Name: real_estates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.real_estates (
    id bigint NOT NULL,
    real_estate_id text,
    email text,
    address text,
    phone_number text,
    why_joined bigint,
    preferred_time timestamp with time zone,
    status text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.real_estates OWNER TO postgres;

--
-- Name: real_estates_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.real_estates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.real_estates_id_seq OWNER TO postgres;

--
-- Name: real_estates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.real_estates_id_seq OWNED BY public.real_estates.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    user_id text,
    first_name text,
    middle_name text,
    last_name text,
    email text,
    enrollment text,
    phone text,
    password text,
    user_name text,
    gender text,
    status text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    role text,
    reset_code bigint
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: inspection_results id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_results ALTER COLUMN id SET DEFAULT nextval('public.inspection_results_id_seq'::regclass);


--
-- Name: properties id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties ALTER COLUMN id SET DEFAULT nextval('public.properties_id_seq'::regclass);


--
-- Name: real_estates id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.real_estates ALTER COLUMN id SET DEFAULT nextval('public.real_estates_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: inspection_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_results (id, inspection_result_id, property_id, inspection_date, satisfactory, comment, landlord_view, tenant_view, image_1, image_1_comment, image_2, image_2_comment, image_3, image_3_comment, image_4, image_4_comment, image_5, image_5_comment, created_at, updated_at) FROM stdin;
\.
COPY public.inspection_results (id, inspection_result_id, property_id, inspection_date, satisfactory, comment, landlord_view, tenant_view, image_1, image_1_comment, image_2, image_2_comment, image_3, image_3_comment, image_4, image_4_comment, image_5, image_5_comment, created_at, updated_at) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (id, property_id, status, user_id, amount, address, coordinate, location, postal_code, street_address, property_type, images, reception_number, bed_number, bath_number, property_details, epc, is_student_property, features, furnished, next_inspection_date, created_at, updated_at, latitude, longitude, landlord_id, tenant_id, inspected) FROM stdin;
\.
COPY public.properties (id, property_id, status, user_id, amount, address, coordinate, location, postal_code, street_address, property_type, images, reception_number, bed_number, bath_number, property_details, epc, is_student_property, features, furnished, next_inspection_date, created_at, updated_at, latitude, longitude, landlord_id, tenant_id, inspected) FROM '$$PATH$$/3376.dat';

--
-- Data for Name: real_estates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.real_estates (id, real_estate_id, email, address, phone_number, why_joined, preferred_time, status, created_at, updated_at) FROM stdin;
\.
COPY public.real_estates (id, real_estate_id, email, address, phone_number, why_joined, preferred_time, status, created_at, updated_at) FROM '$$PATH$$/3378.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, user_id, first_name, middle_name, last_name, email, enrollment, phone, password, user_name, gender, status, created_at, updated_at, role, reset_code) FROM stdin;
\.
COPY public.users (id, user_id, first_name, middle_name, last_name, email, enrollment, phone, password, user_name, gender, status, created_at, updated_at, role, reset_code) FROM '$$PATH$$/3380.dat';

--
-- Name: inspection_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inspection_results_id_seq', 1, false);


--
-- Name: properties_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.properties_id_seq', 19, true);


--
-- Name: real_estates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.real_estates_id_seq', 12, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 80, true);


--
-- Name: users idx_users_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT idx_users_user_id UNIQUE (user_id);


--
-- Name: inspection_results inspection_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_results
    ADD CONSTRAINT inspection_results_pkey PRIMARY KEY (id);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (id);


--
-- Name: real_estates real_estates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.real_estates
    ADD CONSTRAINT real_estates_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_email_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_email_phone ON public.users USING btree (email, phone);


--
-- Name: unique_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_email ON public.users USING btree (email);


--
-- Name: properties fk_users_properties; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT fk_users_properties FOREIGN KEY (landlord_id) REFERENCES public.users(user_id);


--
-- Name: properties fk_users_rental; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT fk_users_rental FOREIGN KEY (tenant_id) REFERENCES public.users(user_id);


--
-- PostgreSQL database dump complete
--

